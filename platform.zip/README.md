# Application deployment
Contract.json
{
    application-name:""
    decription:
    name-of-files:[]
    
    models:[]
}