from unittest.mock import DEFAULT


STORAGE_VM_NAME = 'saiteja3009'
STORAGE_VM_IP = '20.228.199.180'
STORAGE_VM_PASSWORD = 'Saiteja@12345'
MY_PASSWORD = "asdfghjkl@123A"
STORAGE_VM_ADDRESS = 'storage_unit/non_essentials/applications'
STORAGE_VM_ADDRESS_MODELS = 'storage_unit/non_essentials/models'
DEFAULT_DOWNLOAD_PATH = 'files'
