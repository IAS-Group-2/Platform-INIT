UPLOAD_FOLDER = 'files'
TYPE_APP = 1
TYPE_SERVICE = 0
MD_TOPIC = "service_director" #topic of model director
AD_TOPIC = 'app_director' #topic of app director
LBS_TOPIC = 'load_balancer_service_requests' #topic of app director
KAFKA_VM_IP = "20.92.87.205"
KAFKA_VM_PORT = "9092"
